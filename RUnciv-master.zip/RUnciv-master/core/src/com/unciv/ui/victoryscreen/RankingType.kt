package com.unciv.ui.victoryscreen

enum class RankingType {
        Score,
        Population,
        Crop_Yield,
        Production,
        Gold,
        Territory,
        Force,
        Happiness,
        Technologies,
        Culture
    }