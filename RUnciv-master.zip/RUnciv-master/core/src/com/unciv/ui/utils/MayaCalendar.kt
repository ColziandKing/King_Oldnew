package com.unciv.ui.utils

import com.badlogic.gdx.graphics.Color
import com.unciv.logic.civilization.CivilizationInfo
import com.unciv.models.ruleset.unique.UniqueTriggerActivation
import com.unciv.models.ruleset.unique.UniqueType
import com.unciv.models.translations.tr
import kotlin.math.abs

object MayaCalendar {
    // Glyphs / icons
    private const val iconFolder = "MayaCalendar/"
    const val notificationIcon = "MayaCalendar/Maya"
    const val tunIcon = "MayaCalendar/Tun"
    const val katunIcon = "MayaCalendar/Katun"
    const val baktunIcon = "MayaCalendar/Baktun"
    const val tun = 'ම' // U+0DB8, no relation to maya, arbitrary choice (it's the sinhala letter 'mayanna')
    const val katun = 'ඹ' // U+0DB9
    const val baktun = 'ය' // U+0DBA
    // The mayan numerals are actually unicode U+1D2E0 to U+1D2F3, but we can't do those
    // so - I'm replacing the code points for small roman numerals U+2170 to U+2183
    const val zero = 'ⅰ' // U+2170
    const val nineteen = 'Ↄ' // U+2183
    val digits = zero..nineteen
    fun digitIcon(ch: Char) = iconFolder + (ch.code - zero.code).toString()

    // Calculation
    private const val daysOn30000101BCE = 36000 + 5040 + 240 + 11

    private class MayaYear(year: Int) {
        val baktuns: Int
        val katuns: Int
        val tuns: Int

        init {
            val mayaDays = (year + 3000) * 365 + (year + 3000) / 4 + daysOn30000101BCE
            val totalTuns = if (mayaDays >= 0) mayaDays / 360 else 13 * 20 * 20 + mayaDays / 360
            val totalKatuns = totalTuns / 20
            baktuns = totalKatuns / 20
            katuns = totalKatuns - baktuns * 20
            tuns = totalTuns - totalKatuns * 20
        }

        override fun toString(): String {
            val baktunDigit = Char(zero.code + baktuns)
            val katunDigit = Char(zero.code + katuns)
            val tunDigit = Char(zero.code + tuns)
            return "$baktunDigit$baktun$katunDigit$katun$tunDigit$tun"
        }
    }

    fun yearToMayaDate(year: Int) = MayaYear(year).toString()

    // Maya ability implementation
    private fun isNewCycle(year: Int, otherYear: Int) = MayaYear(year).baktuns != MayaYear(otherYear).baktuns

    fun startTurnForMaya(civInfo: CivilizationInfo) {
        val game = civInfo.gameInfo
        val year = game.getYear()
        if (!isNewCycle(year, game.getYear(-1))) return
        for (unique in civInfo.getMatchingUniques(UniqueType.MayanGainGreatPerson)) {
            UniqueTriggerActivation.triggerCivwideUnique(
                unique, civInfo,
                notification = "{A new b'ak'tun has just begun!}\n{A Great Person joins you!}"
            )
        }
    }

    // User interface to explain changed year display
    fun openPopup(previousScreen: BaseScreen, civInfo: CivilizationInfo, year: Int) {
        Popup(previousScreen).apply {
            name = "MayaCalendar"
            addGoodSizedLabel("The Mayan Long Count", 24).apply {
                actor.color = civInfo.nation.getOuterColor()
            }.row()
            addSeparator(color = Color.DARK_GRAY)
            addGoodSizedLabel("Your scientists and theologians have devised a systematic approach to measuring long time spans - the Long Count. During the festivities whenever the current b'ak'tun ends, a Great Person will join you.").row()
            val yearText = ("[" + abs(year) + "] " + (if (year < 0) "BC" else "AD")).tr()
            addGoodSizedLabel("While the rest of the world calls the current year [$yearText], in the Maya Calendar that is:").padTop(10f).row()
            val mayaYear = MayaYear(year)
            addGoodSizedLabel(mayaYear.toString(), 42).row()
            addGoodSizedLabel("[${mayaYear.baktuns}] b'ak'tun, [${mayaYear.katuns}] k'atun, [${mayaYear.tuns}] tun").padBottom(10f).row()
            addCloseButton()
        }.open(true)
    }
}
