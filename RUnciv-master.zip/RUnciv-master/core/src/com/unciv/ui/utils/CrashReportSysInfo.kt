package com.unciv.ui.utils

interface CrashReportSysInfo {
    fun getInfo(): String
}
