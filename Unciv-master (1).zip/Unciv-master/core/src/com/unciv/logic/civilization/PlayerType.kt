package com.unciv.logic.civilization

enum class PlayerType{
    AI,
    Human
}