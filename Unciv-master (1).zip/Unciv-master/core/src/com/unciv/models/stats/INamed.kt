package com.unciv.models.stats

interface INamed {
    var name: String
}
